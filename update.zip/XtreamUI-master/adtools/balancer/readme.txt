You need python package paramiko installed to use this.
apt-get install python-paramiko