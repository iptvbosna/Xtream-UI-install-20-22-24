<?php
include "session.php"; include "functions.php";
if (!$rPermissions["is_admin"] || !hasPermissions("adv", "connection_logs")) { exit; }

$rows = getRegUsersStats();

if ($rSettings["sidebar"]) {
    include "header_sidebar.php";
} else {
    include "header.php";
}


        if ($rSettings["sidebar"]) { ?>
        <div class="content-page"><div class="content"><div class="container-fluid">
        <?php } else { ?>
        <div class="wrapper"><div class="container-fluid">
        <?php } ?>
                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box">
						    <div class="page-title-right">
                                <ol class="breadcrumb m-0">
									<li>
                                        <a href="./reg_users.php">
								        <button type="button" class="btn btn-primary waves-effect waves-light btn-sm"><i class="mdi mdi-keyboard-backspace"></i> <?=$_["back_to_registered_users"]?></button>
									    </a>	
                                    </li>
                                </ol>
                            </div>
                            <h4 class="page-title"> <?=$_["reseller_statistics"]?></h4>
                        </div>
                    </div>
                </div>
                <!-- end page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body" style="overflow-x:auto;">
                                <table id="datatable" class="table table-hover dt-responsive nowrap">
                                    <thead>
                                        <tr>
                                            <th> <?=$_["id"]?></th>
											<th> <?=$_["username"]?></th>
                                            <th> <?=$_["group"]?></th>
                                            <th> <?=$_["owner"]?></th>
                                            <th> <?=$_["unlimited"]?></th>
											<th> <?=$_["active"]?></th>
											<th> <?=$_["expired"]?></th>
											<th class="text-pink"> <?=$_["total_users"]?></th>
											<th> <?=$_["trial"]?></th>
											<th> <?=$_["banned"]?></th>
											<th> <?=$_["disable"]?></th>
											<th> <?=$_["credits"]?></th>
											<th> <?=$_["last_login"]?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                        <?php $stats = 0; 
										while ($row = mysqli_fetch_assoc($rows)) { 
											$reg_id = $row["id"];
											$time = time();?>
										    <td> <a href="./reg_user.php?id=<?=$row["id"]?>"><?php echo $row["id"];?></td>
                                            <td> <a href="./reg_user.php?id=<?=$row["id"]?>"><?php echo $row["username"];?></td>
											<td>
											<a href="./group.php?id=<?=$row["member_group_id"]?>">
										        <?php 
											    $group = $row["member_group_id"];
                                                $query = $db->query("SELECT * from member_groups where group_id = '" . $group . "'");
                                                $name_group = $query->fetch_assoc();
                                                echo $name_group["group_name"]
												?>
											</td>
											<td>
										        <a href="./reg_user.php?id=<?=$row["owner_id"]?>">
										        <?php 
											    $owner_id = $row["owner_id"];
                                                $query = $db->query("SELECT * from reg_users where id = '" . $owner_id . "'");
                                                $owner = $query->fetch_assoc();
                                                echo $owner["username"]
												?>
											</td>	
											<td>
										        <?php 
											    $query = $db->query("SELECT * from users where (member_id = '" . $reg_id . "') AND (is_trial=0) AND (exp_date is NULL)");
                                                $unlimited = $query->num_rows;
                                                echo $unlimited
												?>
											</td>
                                            <td>
                                                <?php 
											    $query = $db->query("SELECT * from users where (member_id = '" . $reg_id . "') AND (is_trial=0) AND (exp_date >'" . $time . "')");
											    $query1 = $db->query("SELECT * from users where (member_id = '" . $reg_id . "') AND (is_trial=1) AND (exp_date >'" . $time . "')");
                                                $active = $query->num_rows;
											    $activer = $query1->num_rows;
                                                $totalactive = $activer + $active;
                                                echo $totalactive
												?>
											</td>
                                            <td>
                                                <?php 
											    $query = $db->query("SELECT * from users where (member_id = '" . $reg_id . "') AND (exp_date < '" . $time . "')");
                                                $expired = $query->num_rows;
                                                echo $expired
												?>
											</td>
                                            <td> <font color=#e36498>
                                                <?php 
											    $query = $db->query("SELECT * from users where member_id = '" . $reg_id . "'");
                                                $total = $query->num_rows;
                                                echo $total
												?>
											</td>
                                            <td>
											    <button type="button" class="btn btn-warning btn-xs btn-fixed waves-effect waves-light">
                                                <?php $query = $db->query("SELECT * from users where (member_id = '" . $reg_id . "') AND (is_trial=1) AND (exp_date >'" . $time . "')");
                                                $test = $query->num_rows;
                                                echo $test
												?>
											</td>
                                            <td>
											    <button type="button" class="btn btn-danger btn-xs btn-fixed waves-effect waves-light">
                                                <?php 
												$query = $db->query("SELECT * from users where (member_id = '" . $reg_id . "') AND (admin_enabled=0)");
                                                $banned = $query->num_rows;
                                                echo $banned
												?>
											</td>
                                            <td>
											    <button type="button" class="btn btn-secondary btn-xs btn-fixed waves-effect waves-light">
                                                <?php 
											    $query = $db->query("SELECT * from users where (member_id = '" . $reg_id . "') AND (enabled=0)");
                                                $disable = $query->num_rows;
                                                echo $disable
												?>
											</td>
											<td>
											    <button type="button" class="btn btn-info btn-xs btn-fixed waves-effect waves-light">
                                                <?php 
											    $credits = $row["credits"];
                                                echo $credits
												?>
											</td>
											<td>
                                            <?php 
											    $lastlogin = $row["last_login"];
                                                echo date("Y-m-d H:i", $lastlogin);
												?>
											</td>  
                                        </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>

                            </div> <!-- end card body-->
                        </div> <!-- end card -->
                    </div><!-- end col-->
                </div>
                <!-- end row-->
            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->
        <?php if ($rSettings["sidebar"]) { echo "</div>"; } ?>
        <!-- Footer Start -->
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 copyright text-center"><?=getFooter()?></div>
                </div>
            </div>
        </footer>
        <!-- end Footer -->

        <script src="assets/js/vendor.min.js"></script>
        <script src="assets/libs/jquery-toast/jquery.toast.min.js"></script>
        <script src="assets/libs/datatables/jquery.dataTables.min.js"></script>
        <script src="assets/libs/datatables/dataTables.bootstrap4.js"></script>
        <script src="assets/libs/select2/select2.min.js"></script>
        <script src="assets/libs/datatables/dataTables.responsive.min.js"></script>
        <script src="assets/libs/datatables/responsive.bootstrap4.min.js"></script>
        <script src="assets/libs/datatables/dataTables.buttons.min.js"></script>
        <script src="assets/libs/datatables/buttons.bootstrap4.min.js"></script>
        <script src="assets/libs/datatables/buttons.html5.min.js"></script>
        <script src="assets/libs/datatables/buttons.flash.min.js"></script>
        <script src="assets/libs/datatables/buttons.print.min.js"></script>
        <script src="assets/libs/datatables/dataTables.keyTable.min.js"></script>
        <script src="assets/libs/datatables/dataTables.select.min.js"></script>
		<script src="assets/libs/moment/moment.min.js"></script>
		<script src="assets/libs/daterangepicker/daterangepicker.js"></script>
        <script src="assets/js/pages/form-remember.js"></script>
        <script src="assets/js/app.min.js"></script>
		

		<script>
        $(document).ready(function() {		
            $("#datatable").DataTable({
                language: {
                    paginate: {
                        previous: "<i class='mdi mdi-chevron-left'>",
                        next: "<i class='mdi mdi-chevron-right'>"
                    }
                },
				columnDefs: [
                    {"className": "dt-center", "targets": [0,1,2,3,4,5,6,7,8,9,10,11,12]},
					{"orderable": false, "targets": []},
                    {"visible": false, "targets": []}
                ],
                drawCallback: function() {
                    $(".dataTables_paginate > .pagination").addClass("pagination");
					$('[data-toggle="tooltip"]').tooltip();
                },
                pageLength: 10,
                lengthMenu: [10, 25, 50, 100, 250],
                responsive: false,
				stateSave: true
            });
            $("#datatable").css("width", "100%");
        });
        </script>
		
    </body>
</html>
