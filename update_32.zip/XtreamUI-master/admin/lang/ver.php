<?php

require 'en.php';

$arr = $_;
$res = array_diff($arr, array_diff(array_unique($arr), array_diff_assoc($arr, array_unique($arr))));
 
foreach(array_unique($res) as $v) {
    echo "Duplicado: $v en la posicion: " .  implode(', ', array_keys($res, $v)) . '<br />';       
}