<?php
include "session.php"; include "functions.php";
if ($rPermissions["is_admin"]) { exit; }
$rStatusArray = Array(0 => "CLOSED", 1 => "OPEN", 2 => "RESPONDED", 3 => "READ");
if ($rSettings["sidebar"]) {
    include "header_sidebar.php";
} else {
    include "header.php";
}
        if ($rSettings["sidebar"]) { ?>
        <div class="content-page"><div class="content"><div class="container-fluid">
        <?php } else { ?>
        <div class="wrapper"><div class="container-fluid">
        <?php } ?>
                <!-- start page title -->
                <!--<div class="row">
                    <div class="col-12">
                        <div class="page-title-box">
                            <h4 class="page-title"><?=$_["dashboard"]?></h4>
                        </div>
                    </div>
                </div>-->     
				<div class="card-box1">
                    
                </div>
                <!-- end page title --> 

                <div class="row">
                    <div class="col-4-md col-xl-3">
                        <div class="card-bg active-connections bg-info1">
							<a href="./live_connections.php">
                            <div class="card-bg active-connections">
						        <div class="p-b-10 p-t-5 p-l-15 p-r-0 d-flex justify-content-between cta-box">
									<?php if ($rAdminSettings["dark_mode"]) { ?>
									<div class="avatar-md">
										<i class="fe-box avatar-title font-24 text-white"></i>
									</div>
									<?php } else { ?>
                                    <div class="avatar-md">
                                        <i class="fe-box avatar-title font-24 text-white"></i>
                                    </div>
									<?php } ?>
                                </div>
							</div>
                            <div class="col-md" align="right">
								<h3 class="text-white my-1"><span data-plugin="counterup" class="entry">0</span></h3>
								<p class="text-white mb-1 text-truncate"><?=$_["open_connections"]?></p>
							</div>
                        </div><br> <!-- end card-box-->
                    </div> <!-- end col -->
					
					<div class="col-4-md col-xl-3">
                        <div class="card-bg online-users bg-success1">
						    <a href="./live_connections.php">
                            <div class="card-bg online-users">
								<div class="p-b-10 p-t-5 p-l-15 p-r-0 d-flex justify-content-between cta-box">
									<?php if ($rAdminSettings["dark_mode"]) { ?>
									<div class="avatar-md">
										<i class="fe-users avatar-title font-24 text-white"></i>
									</div>
									<?php } else { ?>
                                    <div class="avatar-md">
                                        <i class="fe-users avatar-title font-24 text-white"></i>
                                    </div>
									<?php } ?>
                                </div>
							</div>
                            <div class="col-md" align="right">
								<h3 class="text-white my-1"><span data-plugin="counterup" class="entry">0</span></h3>
								<p class="text-white mb-1 text-truncate"><?=$_["online_users"]?></p>
							</div>
                        </div><br> <!-- end card-box-->
                    </div> <!-- end col -->

                    <div class="col-4-md col-xl-3">
                        <div class="card-bg active-accounts bg-pink1">
						    <a href="#">
                            <div class="card-bg active-accounts">
								<div class="p-b-10 p-t-5 p-l-15 p-r-0 d-flex justify-content-between cta-box">
									<?php if ($rAdminSettings["dark_mode"]) { ?>
									<div class="avatar-md">
										<i class="fe-check-circle avatar-title font-24 text-white"></i>
									</div>
									<?php } else { ?>
                                    <div class="avatar-md">
                                        <i class="fe-check-circle avatar-title font-24 text-white"></i>
                                    </div>
									<?php } ?>
                                </div>
							</div>
                            <div class="col-md" align="right">
                                <h3 class="text-white my-1"><span data-plugin="counterup" class="entry">0</span></h3>
                                <p class="text-white mb-1 text-truncate"><?=$_["active_accounts"]?></p>
                            </div>
                        </div><br> <!-- end card-box-->
                    </div> <!-- end col -->

                    <div class="col-4-md col-xl-3">
                        <div class="card-bg credits bg-secondary1">
						    <a href="#">
                            <div class="card-bg credits">
								<div class="p-b-10 p-t-5 p-l-15 p-r-0 d-flex justify-content-between cta-box">
									<?php if ($rAdminSettings["dark_mode"]) { ?>
									<div class="avatar-md">
										<i class="fe-dollar-sign avatar-title font-24 text-white"></i>
									</div>
									<?php } else { ?>
                                    <div class="avatar-md">
                                        <i class="fe-dollar-sign avatar-title font-24 text-white"></i>
                                    </div>
									<?php } ?>
                                </div>
							</div>
                            <div class="col-md" align="right">
                                <h3 class="text-white my-1"><span data-plugin="counterup" class="entry">0</span></h3>
                                <p class="text-white mb-1 text-truncate"><?=$_["credits"]?></p>
                            </div>
                        </div><br> <!-- end card-box-->
                    </div><!-- end col -->
                </div><br>
				<div class="row">
                    <div class="col-xl-6">
                        <div class="card border">
                            <div class="card-body">
                                <h4 class="header-title mb-0"><?=$_["last_10_movies_addeds"]?></h4>
								<div class= separator></div>
                                <div id="cardActivity" class="pt-3">
                                    <div class="text-center">
                                        <?php foreach (getLastMovies() as $rMinfo) { ?>
										<?php
										$rMovieCover = json_decode($rMinfo["movie_propeties"], true);
                                        if (0 < strlen($rMinfo["movie_image"])) {
                                            $rMovieCover = "<a target='_blank' href='https://www.themoviedb.org/movie/" . $rMovieCover["tmdb_id"] . "'><img height='120' width='70' src=" . $rMovieCover["movie_image"] . " /></a>";
                                        } else {
                                            $rMovieCover = "<a target='_blank' href='https://www.themoviedb.org/movie/" . $rMovieCover["tmdb_id"] . "'><img height='120' width='70' src=" . $rMovieCover["movie_image"] . " /></a>";
                                        }                   
									    echo $rMovieCover;
									    ?>		
                                        <?php } ?>
                                    </div>
                                </div>
						    </div>
					     </div>
                    </div><!-- end col -->
                    <div class="col-xl-6">
                        <div class="card border">
                            <div class="card-body">
                                <h4 class="header-title mb-0"><?=$_["last_10_series_addeds"]?></h4>
								<div class= separator></div>
                                <div id="cardActivity" class="pt-3">
                                    <div class="text-center">
                                        <?php foreach (getLastSeries() as $rSinfo) { ?>
									    <?php
                                        if (0 < strlen($rSinfo["cover"])) {
                                            $rSeriesCover = "<a target='_blank' href='https://www.themoviedb.org/tv/" . $rSinfo["tmdb_id"] . "'><img height='120' width='70' src=" . $rSinfo["cover"] . " /></a>";
                                        } else {
                                            $rSeriesCover = "<a target='_blank' href='https://www.themoviedb.org/tv/" . $rSinfo["tmdb_id"] . "'><img height='120' width='70' src=" . $rSinfo["cover"] . " /></a>";
                                        }
										echo $rSeriesCover;
										?>		
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
						</div>
					</div>
					<?php if (($rPermissions["is_reseller"]) && ($rAdminSettings["reseller_view_info"])) { ?>
					<div class="col-12">
					    <?php if ($rAdminSettings["dark_mode"]) { ?>
					    <div class="card-header border bg-dark">
						<?php } else { ?>
						<div class="card-header border bg-white">
						<?php } ?>
					        <a data-toggle="collapse" href="#cardCollpase1" class="arrow-none card-drop" data-parent="#cardCollpase1" role="tablist" aria-expanded="true" aria-controls="cardCollpase1">
							<h4 class="header-title mb-0 mdi mdi-magnify-minus"> <?=$_["news"]?></h4></a>	
							<?php if ($rAdminSettings["dark_mode"]) { ?>
                            <div id="cardCollpase1" class="collapse pt-3 show bg-dark card-box" style="margin-bottom:-8px;">
							<?php } else { ?>
							<div id="cardCollpase1" class="collapse pt-3 show bg-white card-box" style="margin-bottom:-8px;">
							<?php } ?>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="text-left">
                                        <?=$rSettings["userpanel_mainpage"]?>
                                        </div>
                                    </div>
                                </div>
						    </div>
					    </div>
					</div>
					<?php } ?>
                </div><!-- end col -->
				<?php if (($rPermissions["is_reseller"]) && ($rAdminSettings["reseller_view_info"])) { ?>
				<br>
				<?php } ?>
                <div class="row">
                    <div class="col-xl-4">
                        <div class="card border">
                            <div class="card-body">
                                <h4 class="header-title mb-0"><?=$_["recent_activity"]?></h4>
								<div class= separator></div>
                                <div id="cardActivity" class="pt-3">
                                    <div class="slimscroll" style="height:350px;">
                                        <div class="timeline-alt">
                                            <?php 
                                            $rResult = $db->query("SELECT `u`.`username`, `r`.`owner`, `r`.`date`, `r`.`type` FROM `reg_userlog` AS `r` INNER JOIN `reg_users` AS `u` ON `r`.`owner` = `u`.`id` WHERE `r`.`owner` IN (".ESC(join(",", array_keys(getRegisteredUsers($rUserInfo["id"])))).") ORDER BY `r`.`date` DESC LIMIT 100;");
                                            if (($rResult) && ($rResult->num_rows > 0)) {
                                                while ($rRow = $rResult->fetch_assoc()) { ?>
                                                <div class="timeline-item">
                                                    <i class="timeline-icon"></i>
                                                    <div class="timeline-item-info">
                                                        <a href="#" class="text-pink font-weight-semibold mb-1 d-block"><i class="fas fa-user-alt text-secondary"></i> <?=$rRow["username"]?></a>
                                                        <small><?=html_entity_decode($rRow["type"])?></small>
                                                        <p>
                                                            <small class="text-muted"><?=date("d-m-Y H:i:s", $rRow["date"])?></small>
                                                        </p>
                                                    </div>
                                                </div>
                                                <?php }
                                            } ?>
                                        </div>
                                        <!-- end timeline -->
                                    </div> <!-- end slimscroll -->
                                </div> <!-- collapsed end -->
                            </div> <!-- end card-body -->
                        </div> <!-- end card-->
                    </div> <!-- end col-->
                    <div class="col-xl-8">
                        <div class="card border">
                            <div class="card-body">
                                <h4 class="header-title mb-0"><?=$_["expiring_lines"]?></h4>
								<div class= separator></div>
                                <div id="cardActivity" class="pt-3">
                                    <div class="slimscroll" style="height: 350px;">
                                        <table class="table table-hover m-0 table-centered dt-responsive nowrap w-100" id="users-table">
                                            <thead>
                                                <tr>
												    <th class="text-center"><?=$_["id"]?></th>
                                                    <th class="text-center"><?=$_["username"]?></th>
													<th class="text-center"><?=$_["days"]?></th>
                                                    <th class="text-center"><?=$_["reseller"]?></th>
                                                    <th class="text-center"><?=$_["expiration"]?></th>
													<th class="text-center"><?=$_["action"]?></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $rRegisteredUsers = getRegisteredUsers();
												foreach (getExpiring($rUserInfo["id"]) as $rUser) { 
												$today = time();
												$leftdaynumber = (strtotime(date("d-m-Y H:i", $rUser["exp_date"])) - $today)/(60*60*24);
												$leftHourNumber = ($rUser["exp_date"] - $today)/(60*60);
												$leftMinNumber = ($rUser["exp_date"] - $today)/(60);
												if( $leftdaynumber > 0 && $leftdaynumber <= 1){
													$rLeftDate = "1 Day";
												}
												else if($leftdaynumber > 1){
													$rLeftDate = round($leftdaynumber). " Days";
												}
												else if( $leftHourNumber > 0 && $leftHourNumber <= 1){
													$rLeftDate = round($leftMinNumber) . " Minutes";
												}
												else if( round($leftHourNumber) == 1){
													$rLeftDate = "1 Hour";
												}
												else if($leftHourNumber > 1){
													$rLeftDate = round($leftHourNumber)." Hours";
												}
												else{
													$rLeftDate = "<center>-</center>";
												}
												?>
                                                <tr id="user-<?=$rUser["id"]?>">
												    <td class="text-center"><?=$rUser["id"]?></td>
                                                    <td class="text-center"><a href="./user_reseller.php?id=<?=$rUser["id"]?>"><?=$rUser["username"]?></a></td>
													<td class="text-center"><?=$rLeftDate?></td>
                                                    <td class="text-center"><?=$rRegisteredUsers[$rUser["member_id"]]["username"]?></td>
                                                    <td class="text-center"><?=date("Y-m-d H:i:s", $rUser["exp_date"])?></td>
													<td class="text-center"><a href="./user_reseller.php?id=<?=$rUser["id"]?>"><button data-toggle="tooltip" data-placement="top" title="" data-original-title="<?=$_["renew"]?>" type="button" class="btn btn-dark waves-effect waves-light btn-xs"><i class="mdi mdi-autorenew mdi-spin"></i></button></a></td>
                                                </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                    </div> <!-- end slimscroll -->
                                </div> <!-- collapsed end -->
                            </div> <!-- end card-body -->
                        </div> <!-- end card-->
                    </div> <!-- end col-->
                </div>
                <!-- end row -->
               
            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->
        <?php if ($rSettings["sidebar"]) { echo "</div>"; } ?>
        <!-- Footer Start -->
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 copyright text-center"><?=getFooter()?></div>
                </div>
            </div>
        </footer>
        <!-- end Footer -->

        <script src="assets/js/vendor.min.js"></script>
        <script src="assets/libs/jquery-knob/jquery.knob.min.js"></script>
        <script src="assets/libs/peity/jquery.peity.min.js"></script>
        <script src="assets/libs/apexcharts/apexcharts.min.js"></script>
        <script src="assets/libs/datatables/jquery.dataTables.min.js"></script>
        <script src="assets/libs/jquery-number/jquery.number.js"></script>
        <script src="assets/libs/datatables/dataTables.bootstrap4.js"></script>
        <script src="assets/libs/datatables/dataTables.responsive.min.js"></script>
        <script src="assets/libs/datatables/responsive.bootstrap4.min.js"></script>
        <script src="assets/js/pages/dashboard.init.js"></script>
        <script src="assets/js/app.min.js"></script>
        
        <script>
        function getStats() {
            var rStart = Date.now();
            $.getJSON("./api.php?action=reseller_dashboard", function(data) {
                $(".active-connections .entry").html($.number(data.open_connections, 0));
                $(".online-users .entry").html($.number(data.online_users, 0));
                $(".active-accounts .entry").html($.number(data.active_accounts, 0));
                <?php if (floor($rUserInfo["credits"]) == $rUserInfo["credits"]) { ?>
                $(".credits .entry").html($.number(data.credits, 0));
                <?php } else { ?>
                $(".credits .entry").html($.number(data.credits, 2));
                <?php } ?>
                if (Date.now() - rStart < 1000) {
                    setTimeout(getStats, 1000 - (Date.now() - rStart));
                } else {
                    getStats();
                }
            }).fail(function() {
                setTimeout(getStats, 1000);
            });
        }
        
        $(document).ready(function() {
            getStats();
        });
        </script>
    </body>
</html>